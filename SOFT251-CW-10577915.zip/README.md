# SOFT251Assignment
Java Web Application Project - Hospital Management System
