/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Daniel Richards
 */
public class DoctorTest {
    
    public DoctorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getId method, of class Doctor.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Doctor instance = new Doctor();
        String expResult = "D123";
        String result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setId method, of class Doctor.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        String id = "D123";
        Doctor instance = new Doctor();
        instance.setId(id);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFirstName method, of class Doctor.
     */
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Doctor instance = new Doctor();
        String expResult = "Chloe";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFirstName method, of class Doctor.
     */
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "Chloe";
        Doctor instance = new Doctor();
        instance.setFirstName(firstName);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getLastName method, of class Doctor.
     */
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Doctor instance = new Doctor();
        String expResult = "Templeton";
        String result = instance.getLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setLastName method, of class Doctor.
     */
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "Templeton";
        Doctor instance = new Doctor();
        instance.setLastName(lastName);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPassword method, of class Doctor.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Doctor instance = new Doctor();
        String expResult = "password";
        String result = instance.getPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setPassword method, of class Doctor.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "password";
        Doctor instance = new Doctor();
        instance.setPassword(password);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getAddress method, of class Doctor.
     */
    @Test
    public void testGetAddress() {
        System.out.println("getAddress");
        Doctor instance = new Doctor();
        String expResult = "40 Highglen Drive, Plympton, Plymouth, PL5 82A";
        String result = instance.getAddress();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setAddress method, of class Doctor.
     */
    @Test
    public void testSetAddress() {
        System.out.println("setAddress");
        String address = "40 Highglen Drive, Plympton, Plymouth, PL5 82A";
        Doctor instance = new Doctor();
        instance.setAddress(address);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSex method, of class Doctor.
     */
    @Test
    public void testGetSex() {
        System.out.println("getSex");
        Doctor instance = new Doctor();
        String expResult = "Female";
        String result = instance.getSex();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setSex method, of class Doctor.
     */
    @Test
    public void testSetSex() {
        System.out.println("setSex");
        String sex = "Female";
        Doctor instance = new Doctor();
        instance.setSex(sex);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDob method, of class Doctor.
     */
    @Test
    public void testGetDob() {
        System.out.println("getDob");
        Doctor instance = new Doctor();
        String expResult = "30/5/1989";
        String result = instance.getDob();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setDob method, of class Doctor.
     */
    @Test
    public void testSetDob() {
        System.out.println("setDob");
        String dob = "30/5/1989";
        Doctor instance = new Doctor();
        instance.setDob(dob);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getAge method, of class Doctor.
     */
    @Test
    public void testGetAge() {
        System.out.println("getAge");
        Doctor instance = new Doctor();
        int expResult = 30;
        int result = instance.getAge();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setAge method, of class Doctor.
     */
    @Test
    public void testSetAge() {
        System.out.println("setAge");
        int age = 30;
        Doctor instance = new Doctor();
        instance.setAge(age);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    @Test
    public void testRemoveDoctor() {
    }

    @Test
    public void testDeserialize() {
    }
    
}
